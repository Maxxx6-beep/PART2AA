import java.swing.*;
import java.aw.*;
import java.awt.event.*;

Public class ChatbotGUI extends JFrame impliments ActionListener{
    JButton clearButton;
    JButton sendButton;
    JTextArea ChatArea;
    JTextField inpiutField;
    CyberSecurityChatbot bot;
    Public ChatbotGUI() } 

    bot = new CyberSecurityChatbot();
    setLayout(new BorderLayout);
    setLocationRelativeTo(null);
    setSize(500,700);
    SetDefaultCloseOperation(J.Frame.EXIT_ON_CLOSE));
    setLocationRelativeTo(null);
    setLayout(new BorderLayout());
    JPanel1 topPanel1() new JPanel1();
    toPanel1.setBackground(new Colour(26, 25,112));
    JLabel1 titleLabel1 = new JLabel1("Cyber Security Awareness Chatbot");
    titleLabel1.setForeground(Colour.PINK);
    titleLabel1.setFont(new Font("Ariel", Font.BOLD,24));
    topPanel1.add(titleLabel1);
    add(topPanel1, BorderLayout.NORTH);
    chatArea = new JTextArea();
    chatArea.setEditable(False);
    chatArea.setLneWrap(True);
    chatArea.setForeground(Colour.BLUE);
    ChatArea,setBackground(Colour.RED);
    ChatArea.setFont( new Font("Monospaced", Font.PLAIN, 17));

    chatArea.append(

    "========================/n");

    chatArea.append(

   "CYBER SECURITY CHATBOT/N" );

   chatArea.append(

  "[Safe online]/n");

  chatArea.append(

 "============/n/n" );
 chatArea.append(

 "Bot: hello I am Cyber Security Asisstant");

 chatArea.append(

 "Bot: ask me about password,scarms , pisshing and more");
 JScrollPane scrollPane = new JScrollPane(ChatArea);
 add(scrollPane,BorderLayout.CENTER);
 JPanel1 bottomPanel1 = new JPanel1();
 bottomPanel1.setLayout(new BorderLayout());
 inpiutField = new JTextField();
 inpiutField.setFont(new Font("Arial", Font.PLAIN, 16));
 JPanel1 bottomPanel1 = new JPanel1();
 bottomPanel1.add(sendButton);
 bottomPanel1.add(clearButton);
 bottomPanel1.add(inpiutField , BorderLayout.CENTER);
 bottomPanel1.add(bottomPanel1, BorderLayout.EAST);
 add(bottomPanel1,BorderLayout.SOUTH);
 sendButton.addActionListener(this);
 clearButton.addActionListener(this);
 inpiutField.addActionListener(this);
 setVisible(true);
 {

public void actionPerformed(ActionEvent  e) }
if (e.getSource() == sendButton
|| e.getSource() == inpiutField) {
    String userMessage = inpiutField.getText().trim();
    if(userMessage.isEmpty()) {
        return;
    }
chatArea.append("you" + userMessage + "/n");
String response = bot.getResponse(userMessage);
chatArea.append("Bot" + response + "/n");
inpiutField.setText("");

}

if(e.getSource() == clearButton) {


    chatArea.setText("");
    chatArea.append(
        
   "=========/n" );

chatArea.append(


"CYBER SECURITY CHATBOT");

chatArea.append(


"bot: Chat cleared suucessfuly");


}