using System;
using System.Media;



class Program



Console.ForegroundColour = ConsoleColor.Red;
Console.WriteLine(@"



   _____                                    .__   
  /  _  \_______  ______ ____   ____ _____  |  |  
 /  /_\  \_  __ \/  ___// __ \ /    \\__  \ |  |  
/    |    \  | \/\___ \\  ___/|   |  \/ __ \|  |__
\____|__  /__|  /____  >\___  >___|  (____  /____/
        \/           \/     \/     \/     \/      

CYBERSECURITY AWARENESS BOT 
");






Static void Main(string[] args ) 
{
Console.WriteLine("can you Please enter your Name");
String Name= Console.Readline();
}

Console.WriteLine($"\nhello, {Name}!welcome to Cybersecurity awareness bot,i'm here to help you to stay safe online. \n");
SoundPlayer player = new SoundPlayer("sound.wav");
player.Play();


console.WriteLine("if you want safety ways of staying safe,please write 'safety' or 'Cancel' to Quit");
String input = Console.Readline().ToLower();

if (input == "safety")
{
Console.WriteLine("CybersECURITY Safety");
Console.WriteLine("Please ensure that you use strong password and do not click on suspicius links");
}

else if (input == "Cancel");

{

 Console.WriteLine("next time,stay safe online");

}
Console.ReadKey();

if (input.Contains("How are you"))
{

Console.WriteLine("i'm just here ti keep you safe online,i'm just a bot");
}
else if(input.Contains("what is your purpose"))
{


        Console.WriteLine("my main aim is to make sure you learn about cybersecurity and about always staying safe online");

}
else if (input.Contains("password"))
{

        Console.WriteLine("Please ensure that you use a strong password that includes numbers,big and small capital letters and symbols");
        
}

else if (input.Contains("safe browsing"))
{


        Console.WriteLine("Please ensure that you visit safe websites and avoid clicking to unknown links");        
}   
else if (input.Contains("Pishing"))
{

        Console.WriteLine("check out the links that are  suspicius");
}

else 
{
        Console.WriteLine("i did not understand that fully,you can ask me something else");
}
